package gplx.waheed.wordscollection;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


public class SplashActivity extends AppCompatActivity {
    /**************************************
     * Variables
     **************************************************/
    private static int SPLASH_TIME_OUT = 1000;

    /*********************************************
     * onCreate
     ***************************************/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        loadNextScreen();
    }

    /**************************************
     * loadNextScreen
     **********************************************/
    private void loadNextScreen() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(SplashActivity.this,
                        SecondActivity.class);
                startActivity(i);
                overridePendingTransition(R.anim.right_in, R.anim.left_out);
                finish();


            }
        }, SPLASH_TIME_OUT);
    }
    /************************************** END ***************************************************/

}
