package gplx.waheed.wordscollection.ormlitedb;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "WordsTable")
public class WordsDataORM {

    @DatabaseField(generatedId = true)
    int id;
    @DatabaseField(index = true)
    String word;
    @DatabaseField
    String details;
    @DatabaseField
    String sentences;
    @DatabaseField
    long millis;
    @DatabaseField
    String date;

    public WordsDataORM() {
    }

    public WordsDataORM(String word, String details, String sentences,
                        long millis) {
        this.word = word;
        this.details = details;
        this.sentences = sentences;
        this.millis = millis;
        Date date = new Date();
        date.setTime(millis);
        String formattedDate = new SimpleDateFormat("dd MMM yyyy , hh:mm a")
                .format(date);
        this.date = formattedDate;

    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public long getMillis() {
        return millis;
    }

    public void setMillis(long millis) {
        this.millis = millis;
    }

    public String getSentences() {
        return sentences;
    }

    public void setSentences(String sentences) {
        this.sentences = sentences;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }
}
