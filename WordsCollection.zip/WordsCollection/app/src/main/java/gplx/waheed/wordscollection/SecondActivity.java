package gplx.waheed.wordscollection;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.speech.tts.TextToSpeech;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.j256.ormlite.android.apptools.OpenHelperManager;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.stmt.DeleteBuilder;
import com.j256.ormlite.stmt.QueryBuilder;
import com.j256.ormlite.stmt.UpdateBuilder;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import gplx.waheed.wordscollection.ormlitedb.DatabaseHelper;
import gplx.waheed.wordscollection.ormlitedb.WordsDataORM;


public class SecondActivity extends AppCompatActivity implements
        TextToSpeech.OnInitListener {

    //Delimiter used in CSV file
    private static final String COMMA_DELIMITER = ",";
    private static final String NEW_LINE_SEPARATOR = "\n";
    /**************************************************************************************
     * Variables
     **************************************************************************************/
    private boolean doImport = false, doExport = false, doEmail = false;
    private InterstitialAd interstitial;
    private CountDownTimer countDownTimer;
    private String keyGpaInterstitialAdds = "ADDS_Counter_GPA";
    private CountDownTimer interstitialAddsTimer;
    private AdView mAdViewBanner;
    private AdRequest adRequest;
    private RecyclerView recyclerView;
    private Dialog addWordsDialog;
    private FloatingActionButton fabAddWords;
    private CollapsingToolbarLayout collapsingToolbar;
    private ArrayList<WordsDataORM> listOfWords;
    private Toolbar toolbar;
    private DatabaseHelper dbHelper;
    private String keySortAlphabatically = "AlphabaticallSort";
    private WordsAdapter wordAdapter;
    private TextToSpeech tts;
    private AlertDialog.Builder dialogSingleChoice;
    private CharSequence[] choiceOptions = {"Copy Word's detail", "Speak Words's detail", "Speak Word's Sentences"};
    final private int REQUEST_CODE_ASK_PERMISSIONS = 123;

    /**************************************************************************************
     * onCreate
     **************************************************************************************/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        loadUI();
        listeners();
        loadBannerAd();
        interstitial = new InterstitialAd(this);
        interstitial.setAdUnitId(getResources().getString(R.string.interstitial_ad_unit_id));
    }

    /**************************************************************************************
     * loadUI
     **************************************************************************************/
    private void loadUI() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        collapsingToolbar = (CollapsingToolbarLayout) findViewById(R.id.collapsing_toolbar);
        listOfWords = new ArrayList<WordsDataORM>();
        fabAddWords = (FloatingActionButton) findViewById(R.id.fabAddWords);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerviewMyGpasId);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        dbHelper = OpenHelperManager.getHelper(this,
                DatabaseHelper.class);
        wordAdapter = new WordsAdapter(listOfWords);
        recyclerView.setAdapter(wordAdapter);
        if (getBooleanFromPrefs(keySortAlphabatically)) {
            loadSortedDataFromDb();
        } else {
            loadDataFromDb();
        }
    }

    /**************************************************************************************
     * loadDataFromDb
     **************************************************************************************/
    private void loadDataFromDb() {
        try {
            listOfWords.clear();
            Dao<WordsDataORM, Integer> wordDao = dbHelper.getWordsDao();
            List<WordsDataORM> wordsList = wordDao.queryForAll();
            if (wordsList.size() > 0) {
                collapsingToolbar.setTitle("Vocabulary(" + wordsList.size() + ")");
            } else {
                collapsingToolbar.setTitle("Add vocabulary");
            }
            listOfWords.addAll(wordsList);
            wordAdapter.notifyDataSetChanged();
            wordDao.closeLastIterator();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**************************************************************************************
     * loadSortedDataFromDb
     **************************************************************************************/
    private void loadSortedDataFromDb() {
        try {
            listOfWords.clear();
            Dao<WordsDataORM, Integer> wordDao = dbHelper.getWordsDao();
            QueryBuilder<WordsDataORM, Integer> builder = wordDao.queryBuilder();
            builder.orderBy("word", true);// true for asc false dsce
            List<WordsDataORM> wordsList = wordDao.query(builder.prepare());
            if (wordsList.size() > 0) {
                collapsingToolbar.setTitle("Vocabulary(" + wordsList.size() + ")");
            } else {
                collapsingToolbar.setTitle("Add vocabulary");
            }
            listOfWords.addAll(wordsList);
            wordAdapter.notifyDataSetChanged();
            wordDao.closeLastIterator();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**************************************************************************************
     * listeners
     **************************************************************************************/
    private void listeners() {
        tts = new TextToSpeech(this, this);
        fabAddWords.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // For Interstitial Adds
                int count = getIntegerFromPrefs(keyGpaInterstitialAdds);
                count = count - 1;
                putIntegerInPrefs(keyGpaInterstitialAdds, count);
                if (count <= 0) {
                    //3 Times clicked so show add after 15 sec
                    interstitialTimerMethod();
                }
                showAddWordsDialog();
            }
        });
    }

    /**************************************************************************************
     * onInit
     **************************************************************************************/
    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(Locale.getDefault());
            if (result == TextToSpeech.LANG_MISSING_DATA
                    || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                showToast("Language does not supported to speak");
            } else {
                //speakOut();
            }

        } else {
            Log.e("TTS", "Initilization Failed");
        }

    }

    /**************************************************************************************
     * speakOut
     **************************************************************************************/
    private void speakOut(String text) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    /**************************************************************************************
     * onDestroy
     **************************************************************************************/
    @Override
    public void onDestroy() {
        // Don't forget to shutdown!
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        try {
            if (mAdViewBanner.isEnabled() && mAdViewBanner != null) {
                mAdViewBanner.destroy();
            }
            interstitialAddsTimer.cancel();
        } catch (Exception e) {
        }
        super.onDestroy();
    }

    /**************************************************************************************
     * onCreateOptionsMenu
     **************************************************************************************/
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_second, menu);
        return true;
    }

    /**************************************************************************************
     * onOptionsItemSelected
     **************************************************************************************/
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.importVocId) {
            confirmCSVImportDialog();
            return true;
        }
        if (id == R.id.exportVocId) {
            confirmCSVExportDialog();
            return true;
        }
        if (id == R.id.emailVocId) {
            if (Build.VERSION.SDK_INT >= 23) {
                // Marshmallow+ check storage permission
                int hasWriteStoragePermission = ContextCompat.checkSelfPermission(SecondActivity.this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE);
                if (hasWriteStoragePermission != PackageManager.PERMISSION_GRANTED) {
                    doEmail = true;
                    emailVocabulary();
                } else {
                    emailVocabulary();
                }
            } else {
                emailVocabulary();

            }
            return true;
        }
        if (id == R.id.sortAlphabaticallyVocId) {
            putBooleanInPrefs(keySortAlphabatically, true);
            loadSortedDataFromDb();
            return true;
        }
        if (id == R.id.sortAsOriginalId) {
            putBooleanInPrefs(keySortAlphabatically, false);
            loadDataFromDb();
            return true;
        }


        return super.onOptionsItemSelected(item);
    }

    /**************************************************************************************
     * showAddWordsDialog
     **************************************************************************************/
    private void showAddWordsDialog() {
        addWordsDialog = new Dialog(this);
        addWordsDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        addWordsDialog.getWindow().setBackgroundDrawable(
                new ColorDrawable(android.graphics.Color.TRANSPARENT));
        addWordsDialog.setContentView(R.layout.add_word_dialog);
        addWordsDialog.setCancelable(false);
        final EditText etWord = (EditText) addWordsDialog.findViewById(R.id.etWordId);
        final EditText etDetails = (EditText) addWordsDialog.findViewById(R.id.etDetailsId);
        final EditText etSentences = (EditText) addWordsDialog.findViewById(R.id.etSentencesId);

        Button save = (Button) addWordsDialog
                .findViewById(R.id.btnSaveId);
        save.setText("Save");
        Button cancel = (Button) addWordsDialog
                .findViewById(R.id.btnCancelId);
        cancel.setText("Cancel");

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String word = etWord.getText().toString().replace("\n", " ").trim();
                String details = etDetails.getText().toString().replace("\n", " ").trim();
                String sentence = etSentences.getText().toString().replace("\n", " ").trim();
                if (!word.equals("") && !details.equals("") && !sentence.equals("")) {
                    try {
                        Dao<WordsDataORM, Integer> wordDao = dbHelper.getWordsDao();
                        wordDao.create(new WordsDataORM(word, details, sentence, System.currentTimeMillis()));
                        Toast.makeText(SecondActivity.this, "Word added successfully", Toast.LENGTH_SHORT).show();
                        wordDao.closeLastIterator();
                        if (getBooleanFromPrefs(keySortAlphabatically)) {
                            loadSortedDataFromDb();
                        } else {
                            loadDataFromDb();
                        }
                        addWordsDialog.dismiss();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    Toast.makeText(SecondActivity.this, "Plz fill all feilds", Toast.LENGTH_SHORT).show();
                }
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addWordsDialog.dismiss();
            }
        });
        addWordsDialog.show();

    }

    /**************************************************************************************
     * showEditWordsDialog
     **************************************************************************************/
    private void showEditWordsDialog(final WordsDataORM wordObject) {
        addWordsDialog = new Dialog(this);
        addWordsDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        addWordsDialog.getWindow().setBackgroundDrawable(
                new ColorDrawable(android.graphics.Color.TRANSPARENT));
        addWordsDialog.setContentView(R.layout.add_word_dialog);
        addWordsDialog.setCancelable(true);
        final EditText etWord = (EditText) addWordsDialog.findViewById(R.id.etWordId);
        final EditText etDetails = (EditText) addWordsDialog.findViewById(R.id.etDetailsId);
        final EditText etSentences = (EditText) addWordsDialog.findViewById(R.id.etSentencesId);

        etWord.setText(wordObject.getWord());
        etSentences.setText(wordObject.getSentences());
        etDetails.setText(wordObject.getDetails());

        Button save = (Button) addWordsDialog
                .findViewById(R.id.btnSaveId);
        save.setText("Update");
        Button cancel = (Button) addWordsDialog
                .findViewById(R.id.btnCancelId);
        cancel.setText("Delete");
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Working as Update
                String word = etWord.getText().toString().replace("\n", " ").trim();
                String details = etDetails.getText().toString().replace("\n", " ").trim();
                String sentence = etSentences.getText().toString().replace("\n", " ").trim();
                if (!word.equals("") && !details.equals("") && !sentence.equals("")) {
                    confirmUpdateDialog(wordObject.getId(), word, details, sentence);
                } else {
                    Toast.makeText(SecondActivity.this, "Plz fill all feilds", Toast.LENGTH_SHORT).show();
                }
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Working as a delete
                confirmDeleteDialog(wordObject.getId());
            }
        });
        addWordsDialog.show();

    }

    /**************************************************************************************
     * emailVocabulary
     **************************************************************************************/
    private void emailVocabulary() {
        try {
            String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/vocabulary.csv";
            File file = new File(path);
            if (file.exists()) {
                writeDataIntoFIle();
                Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                sharingIntent.setType("vnd.android.cursor.dir/email");
                sharingIntent.setType("application/x-vcard");
                sharingIntent.putExtra(Intent.EXTRA_EMAIL, "");
                sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "My Vocabulary");
                sharingIntent.putExtra(Intent.EXTRA_STREAM, Uri.parse("file://" + path));
                startActivity(Intent.createChooser(sharingIntent, "Send email"));
            } else {
                Toast.makeText(SecondActivity.this, "File not exists please export it first", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**************************************************************************************
     * confirmCSVImportDialog
     **************************************************************************************/
    private void confirmCSVImportDialog() {

        AlertDialog.Builder alertDialog = new AlertDialog.Builder(
                SecondActivity.this);
        alertDialog.setTitle("Import CSV...");
        alertDialog.setMessage("Do you want to import vocabulary?");
        alertDialog.setIcon(R.mipmap.ic_launcher);

        alertDialog.setPositiveButton("YES",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        if (Build.VERSION.SDK_INT >= 23) {
                            // Marshmallow+ check storage permission
                            int hasWriteStoragePermission = ContextCompat.checkSelfPermission(SecondActivity.this,
                                    Manifest.permission.WRITE_EXTERNAL_STORAGE);
                            if (hasWriteStoragePermission != PackageManager.PERMISSION_GRANTED) {
                                doImport = true;
                                checkAndAskStoragePermission();
                            } else {
                                readDataFromFile();
                            }
                        } else {
                            readDataFromFile();

                        }
                    }
                });
        alertDialog.setNegativeButton("NO",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

        alertDialog.show();

    }

    /**************************************************************************************
     * confirmDeleteDialog
     **************************************************************************************/
    private void confirmDeleteDialog(final int id) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(
                SecondActivity.this);
        alertDialog.setTitle("Delete...");
        alertDialog.setMessage("Do you want to delete word and its data?");
        alertDialog.setIcon(R.mipmap.ic_launcher);

        alertDialog.setPositiveButton("YES",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            dialog.cancel();
                            Dao<WordsDataORM, Integer> wordDao = dbHelper.getWordsDao();
                            DeleteBuilder<WordsDataORM, Integer> deleteBuilder = wordDao
                                    .deleteBuilder();
                            deleteBuilder.where().eq("id", id);
                            deleteBuilder.delete();
                            wordDao.closeLastIterator();
                            if (getBooleanFromPrefs(keySortAlphabatically)) {
                                loadSortedDataFromDb();
                            } else {
                                loadDataFromDb();
                            }
                            addWordsDialog.dismiss();
                            Toast.makeText(SecondActivity.this, "Deleted successfully", Toast.LENGTH_SHORT).show();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
        alertDialog.setNegativeButton("NO",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

        alertDialog.show();

    }

    /************************************************************************
     * onPause
     ***************************************************************************/
    @Override
    public void onPause() {
        if (mAdViewBanner.isEnabled() && mAdViewBanner != null) {
            mAdViewBanner.pause();
        }
        super.onPause();
    }

    /**********************************************************************
     * onResume
     ************************************************************************/
    @Override
    public void onResume() {
        super.onResume();
        try {
            AdRequest adRequest = new AdRequest.Builder().build();
            interstitial.loadAd(adRequest);
            if (mAdViewBanner.isEnabled() && mAdViewBanner != null) {
                mAdViewBanner.resume();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            if (mAdViewBanner.isEnabled() && mAdViewBanner != null) {
                mAdViewBanner.resume();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*******************************************************************
     * loadBannerAd
     **********************************************************************/
    public void loadBannerAd() {
        try {
            mAdViewBanner = (AdView) findViewById(R.id.adViewBannerGpaId);
            adRequest = new AdRequest.Builder().build();
            mAdViewBanner.loadAd(adRequest);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*******************************************************************
     * loadBannerAd
     **********************************************************************/
    public void loadBannerAd(View v) {
        try {
            mAdViewBanner = (AdView) v.findViewById(R.id.adViewBannerGpaId);
            adRequest = new AdRequest.Builder().build();
            mAdViewBanner.loadAd(adRequest);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**********************************************************************
     * displayInterstitialAds
     *************************************************************************/
    public void displayInterstitialAds() {
        if (interstitial != null && interstitial.isLoaded()) {
            putIntegerInPrefs(keyGpaInterstitialAdds, 3);
            interstitial.show();
        }
    }

    /***********************************************************************
     * putIntegerInPrefs
     ******************************************************************************/
    private void putIntegerInPrefs(String tag, Integer value) {
        try {
            SharedPreferences prefs = PreferenceManager
                    .getDefaultSharedPreferences(SecondActivity.this);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putInt(tag, value);
            editor.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /***********************************************************************
     * getIntegerFromPrefs
     ******************************************************************************/
    private Integer getIntegerFromPrefs(String tag) {
        Integer res = 0;
        try {
            SharedPreferences prefs = PreferenceManager
                    .getDefaultSharedPreferences(SecondActivity.this);
            res = prefs.getInt(tag, 3);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }

    /************************************************************************
     * interstitialTimerMethod
     *************************************************************************/
    private void interstitialTimerMethod() {
        interstitialAddsTimer = new CountDownTimer(1500, 1500) {
            public void onTick(long millisUntilFinished) {
            }

            public void onFinish() {
                displayInterstitialAds();
            }
        };
        interstitialAddsTimer.start();

    }

    /**************************************************************************************
     * confirmUpdateDialog
     **************************************************************************************/
    private void confirmUpdateDialog(final int id, final String word, final String details, final String sentence) {

        AlertDialog.Builder alertDialog = new AlertDialog.Builder(
                SecondActivity.this);
        alertDialog.setTitle("Update...");
        alertDialog.setMessage("Do you want to update this vocabulary?");
        alertDialog.setIcon(R.mipmap.ic_launcher);

        alertDialog.setPositiveButton("YES",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            dialog.cancel();
                            Dao<WordsDataORM, Integer> wordDao = dbHelper.getWordsDao();
                            UpdateBuilder<WordsDataORM, Integer> updateBuilder = wordDao.updateBuilder();
                            updateBuilder.where().eq("id", id);
                            updateBuilder.updateColumnValue("word", word); //updating
                            updateBuilder.updateColumnValue("details", details); //updating
                            updateBuilder.updateColumnValue("sentences", sentence); //updating
                            updateBuilder.update();
                            Toast.makeText(SecondActivity.this, "Word updated successfully", Toast.LENGTH_SHORT).show();
                            wordDao.closeLastIterator();
                            if (getBooleanFromPrefs(keySortAlphabatically)) {
                                loadSortedDataFromDb();
                            } else {
                                loadDataFromDb();
                            }
                            addWordsDialog.dismiss();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
        alertDialog.setNegativeButton("NO",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

        alertDialog.show();

    }

    /**************************************************************************************
     * confirmCSVExportDialog
     **************************************************************************************/
    private void confirmCSVExportDialog() {

        AlertDialog.Builder alertDialog = new AlertDialog.Builder(
                SecondActivity.this);
        alertDialog.setTitle("Export CSV...");
        alertDialog.setMessage("Do you want to export vocabulary?");
        alertDialog.setIcon(R.mipmap.ic_launcher);

        alertDialog.setPositiveButton("YES",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        if (Build.VERSION.SDK_INT >= 23) {
                            // Marshmallow+ check storage permission
                            int hasWriteStoragePermission = ContextCompat.checkSelfPermission(SecondActivity.this,
                                    Manifest.permission.WRITE_EXTERNAL_STORAGE);
                            if (hasWriteStoragePermission != PackageManager.PERMISSION_GRANTED) {
                                doExport = true;
                                checkAndAskStoragePermission();
                            } else {
                                writeDataIntoFIle();
                                Toast.makeText(SecondActivity.this, "Successfully exported vocabulary as a CSV file", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            writeDataIntoFIle();
                            Toast.makeText(SecondActivity.this, "Successfully exported vocabulary as a CSV file", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
        alertDialog.setNegativeButton("NO",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

        alertDialog.show();

    }

    /**************************************************************************************
     * confirmExitAppDialog
     **************************************************************************************/
    private void confirmExitAppDialog() {

        AlertDialog.Builder alertDialog = new AlertDialog.Builder(
                SecondActivity.this);
        alertDialog.setTitle("Exit App...");
        alertDialog.setMessage("Do you want to exit?");
        alertDialog.setIcon(R.mipmap.ic_launcher);

        alertDialog.setPositiveButton("YES",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                        overridePendingTransition(R.anim.right_in, R.anim.left_out);
                    }
                });
        alertDialog.setNegativeButton("NO",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

        alertDialog.show();

    }

    /**************************************************************************************
     * onBackPressed
     **************************************************************************************/
    @Override
    public void onBackPressed() {
        confirmExitAppDialog();
    }

    /**************************************************************************************
     * isSDCardWritable
     **************************************************************************************/
    /* Checks if SD Card is available for read and write */
    public boolean isSDCardWritable() {
        String status = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(status)) {
            return true;
        }
        return false;
    }

    /**************************************************************************************
     * writeDataIntoFIle
     **************************************************************************************/
    private void writeDataIntoFIle() {
        if (isSDCardWritable()) {
            String dataToSave = "";
            try {
                File sdCard = Environment.getExternalStorageDirectory();
                FileWriter fileWriter = new FileWriter(sdCard.getAbsolutePath() + "/vocabulary.csv");
                Dao<WordsDataORM, Integer> wordDao = dbHelper.getWordsDao();
                List<WordsDataORM> wordsList = wordDao.queryForAll();

                for (WordsDataORM obj : wordsList) {
                    fileWriter.write(obj.getWord().replaceAll(COMMA_DELIMITER, " __ "));
                    fileWriter.write(COMMA_DELIMITER);
                    fileWriter.write(obj.getDetails().replaceAll(COMMA_DELIMITER, " __ "));
                    fileWriter.write(COMMA_DELIMITER);
                    fileWriter.write(obj.getSentences().replaceAll(COMMA_DELIMITER, " __ "));
                    fileWriter.write(NEW_LINE_SEPARATOR);
                }
                fileWriter.flush();
                fileWriter.close();
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(getBaseContext(), e.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(getBaseContext(), "SD Card Not Available",
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**************************************************************************************
     * isSDCardReadable
     **************************************************************************************/
    /* Checks if SD Card is available to at least read */
    public boolean isSDCardReadable() {
        String status = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(status)
                || Environment.MEDIA_MOUNTED_READ_ONLY.equals(status)) {
            return true;
        }
        return false;
    }

    /**************************************************************************************
     * readDataFromFile
     **************************************************************************************/
    private void readDataFromFile() {
        if (isSDCardReadable()) {
            try {
                // SD Card Storage
                File sdCard = Environment.getExternalStorageDirectory();
                String line = "";
                //Create the file reader
                BufferedReader fileReader = new BufferedReader(new FileReader(sdCard.getAbsolutePath() + "/vocabulary.csv"));
                Dao<WordsDataORM, Integer> wordDao = dbHelper.getWordsDao();
                QueryBuilder<WordsDataORM, Integer> builder = wordDao.queryBuilder();
                List<WordsDataORM> list = null;
                //Read the file line by line starting from the second line
                while ((line = fileReader.readLine()) != null) {
                    //Get all tokens available in line
                    String[] tokens = line.split(COMMA_DELIMITER);
                    if (tokens.length > 0) {
                        String word = tokens[0].replaceAll(" __ ", ",").toString();
                        String details = tokens[1].replaceAll(" __ ", ",").toString();
                        String sentence = tokens[2].replaceAll(" __ ", ",").toString();
                        builder.where().eq("word", word);
                        list = wordDao.query(builder.prepare());
                        if (list.size() > 0) {
                            // Already exist in DB do not replace
                        } else {
                            wordDao.create(new WordsDataORM(word, details, sentence, System.currentTimeMillis()));
                        }
                        list.clear();
                    }
                }
                wordDao.closeLastIterator();
                if (getBooleanFromPrefs(keySortAlphabatically)) {
                    loadSortedDataFromDb();
                } else {
                    loadDataFromDb();
                }
                Toast.makeText(getBaseContext(), "Successfully imported vocabulary from CSV file",
                        Toast.LENGTH_SHORT).show();

            } catch (Exception e) {
                e.printStackTrace();
            }

        } else {
            Toast.makeText(getBaseContext(), "SD Card Not Available",
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * ****************************************** getBooleanFromPrefs ******************************
     */
    protected boolean getBooleanFromPrefs(String tag) {
        boolean res = false;
        try {
            SharedPreferences prefs = PreferenceManager
                    .getDefaultSharedPreferences(SecondActivity.this);
            res = prefs.getBoolean(tag, false);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return res;
    }

    /**
     * ****************************************** putBooleanInPrefs ********************************
     */
    protected void putBooleanInPrefs(String tag, boolean value) {
        try {
            SharedPreferences prefs = PreferenceManager
                    .getDefaultSharedPreferences(SecondActivity.this);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean(tag, value);
            editor.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**************************************************************************************
     * showToast
     **************************************************************************************/
    private void showToast(String text) {
        Toast.makeText(SecondActivity.this, text, Toast.LENGTH_SHORT).show();
    }

    /************************
     * optionsDialog1
     *******************************/
    public void optionsDialog1(final int position) {
        try {
            dialogSingleChoice = new AlertDialog.Builder(SecondActivity.this);
            dialogSingleChoice.setTitle("Choose Option");
            final ClipboardManager clipboard = (ClipboardManager)
                    getSystemService(Context.CLIPBOARD_SERVICE);
            dialogSingleChoice.setSingleChoiceItems(choiceOptions, -1,
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            WordsDataORM obj = listOfWords.get(position);
                            if (which == 0) {
                                String text = obj.getWord() + " " + obj.getDetails() + " " + obj.getSentences();
                                ClipData clip = ClipData.newPlainText(
                                        "label", text);
                                clipboard.setPrimaryClip(clip);
                                showToast("Copied...");
                            } else if (which == 1) {
                                String text = obj.getWord() + " " + obj.getDetails();
                                speakOut(text);
                            } else if (which == 2) {
                                String text = obj.getSentences();
                                speakOut(text);
                            }
                            dialog.cancel();
                        }
                    });
            dialogSingleChoice.setNegativeButton("Cancel",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            AlertDialog alert_dialogForProfiles = dialogSingleChoice.create();
            alert_dialogForProfiles.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /******************************************************************************************
     * checkAndAskStoragePermission
     *******************************************************************************************/
    private void checkAndAskStoragePermission() {
        int hasWriteStoragePermission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (hasWriteStoragePermission != PackageManager.PERMISSION_GRANTED) {
            if (!ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                showMessageOKCancel("You need to allow access to read and write vocabulary in device storage.",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ActivityCompat.requestPermissions(SecondActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                        REQUEST_CODE_ASK_PERMISSIONS);
                            }
                        });
                return;
            }
            ActivityCompat.requestPermissions(SecondActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    REQUEST_CODE_ASK_PERMISSIONS);
            return;
        }
    }

    /******************************************************************************************
     * onRequestPermissionsResult
     *******************************************************************************************/
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_ASK_PERMISSIONS:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permission Granted
                    if (doImport) {
                        doImport = false;
                        readDataFromFile();
                    } else if (doExport) {
                        doExport = false;
                        writeDataIntoFIle();
                        Toast.makeText(SecondActivity.this, "Successfully exported vocabulary as a CSV file", Toast.LENGTH_SHORT).show();
                    } else if (doEmail) {
                        doEmail = false;
                        emailVocabulary();
                    }
                } else {
                    showToast("Storage access denied");
                    showToast("You need to allow access to read and write vocabulary from device storage");
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    /******************************************************************************************
     * listeners
     *******************************************************************************************/
    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(SecondActivity.this)
                .setMessage(message)
                .setPositiveButton("OK", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    /**************************************************************************************
     * WordsAdapter
     **************************************************************************************/
    private class WordsAdapter extends RecyclerView.Adapter<WordsAdapter.ViewHolder> {

        private ArrayList<WordsDataORM> data = new ArrayList<>();
        private ArrayList<WordsDataORM> searchList = new ArrayList<>();

        public WordsAdapter(ArrayList<WordsDataORM> data) {
            this.data = data;
            searchList.addAll(data);
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.listitem_words, viewGroup, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(ViewHolder viewHolder, final int ipos) {

            viewHolder.tvWord.setText(data.get(ipos).getWord());
            viewHolder.tvDetails.setText(data.get(ipos).getDetails());
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        public void filter(String charText) {
            /*charText = charText.toLowerCase();
            listOfWords.clear();
            if (charText.length() == 0) {
                listOfWords.addAll(searchList);
            } else {
                for (WordsDataORM sw : searchList) {
                    if (sw.getWord().toLowerCase().contains(charText)
                            || sw.getDetails().toLowerCase()
                            .contains(charText)
                            || sw.getSentences().toLowerCase()
                            .contains(charText)
                            || sw.getDate().toLowerCase()
                            .contains(charText)) {
                        listOfWords.add(sw);
                    }
                }
            }
            notifyDataSetChanged();*/
        }


        public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener {

            private TextView tvWord, tvDetails;
            private ImageView speak;

            ViewHolder(View v) {
                super(v);
                tvWord = (TextView) v.findViewById(R.id.tvWordsId);
                tvDetails = (TextView) v.findViewById(R.id.tvDetailsId);
                speak = (ImageView) v.findViewById(R.id.ivSpeakId);
                v.setOnClickListener(this);
                v.setOnLongClickListener(this);
                speak.setOnClickListener(this);
            }

            @Override
            public boolean onLongClick(View v) {
                int position = getLayoutPosition(); // gets item position
                //showToast(data.get(position).getWord() + " " + position);
                optionsDialog1(position);
                return false;
            }


            @Override
            public void onClick(View v) {
                int position = getLayoutPosition(); // gets item position
                if (v.getId() == R.id.ivSpeakId) {
                    WordsDataORM obj = data.get(position);
                    speakOut(obj.getWord());
                } else {
                    WordsDataORM obj = data.get(position);
                    showEditWordsDialog(obj);
                }
            }
        }

    }

    /**************************************************************************************
     * END
     **************************************************************************************/
}
